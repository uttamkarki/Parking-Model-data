﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Paking_model
{
    public partial class Form1 : Form
    {
        StringBuilder csvcontent = new StringBuilder();
        int i = 1;
        
        public Form1()
        {
            InitializeComponent();
            
        }

        public string entrytime { get; set; }
        public string parkedtime { get; set; }
        public string exittime { get; set; }
        public string filepath { get; set; }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text =  DateTime.Now.ToString("HH:mm:ss tt");
            string startTime = (textBox3.Text);
            entrytime = startTime;

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox8.Text = DateTime.Now.ToString("HH:mm:ss tt");
            string endtime = (textBox8.Text);
            parkedtime = endtime;

            if (checkBox1.Checked == true)
            {
                TimeSpan duration = DateTime.Parse(endtime).Subtract(DateTime.Parse(entrytime));
                textBox6.Text = Convert.ToString(duration);
            }
            

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                checkBox2.Checked = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox7.Text = DateTime.Now.ToString("HH:mm:ss tt");
            string exittme = textBox7.Text;
            exittime = exittme;

            if (checkBox2.Checked == true)
            {
                TimeSpan duration = DateTime.Parse(exittime).Subtract(DateTime.Parse(entrytime));
                textBox6.Text = Convert.ToString(duration);
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true)
            {
                checkBox1.Checked = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear(); textBox5.Clear(); textBox6.Clear(); textBox7.Clear(); textBox8.Clear();
            checkBox1.Checked = false; checkBox2.Checked = false; checkBox3.Checked = false; checkBox4.Checked = false;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                checkBox3.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                checkBox4.Checked = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string parked = null;
            while(checkBox1.Checked == true)
            {
                parked = "Yes";
                break;
            }
            while (checkBox2.Checked == true)
            {
                parked = "No";
                break;
            }
            while (checkBox3.Checked == true)
            {
                textBox5.Text = "F";
                break;
            }
            while (checkBox4.Checked == true)
            {
                textBox5.Text = "C";
                break;
            }

            var newline = string.Format("{0},{1},{2},{3},{4},{5},{6},{7}",textBox1.Text, textBox2.Text, 
                    textBox3.Text, parked, textBox8.Text, textBox5.Text, textBox6.Text, textBox7.Text);
            csvcontent.AppendLine(newline);
            textBox10.Text = Convert.ToString(i);
            i++;
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var folderlocation = new FolderBrowserDialog();
            DialogResult dialog = folderlocation.ShowDialog();
            string filepath = "Link";
            if(dialog == DialogResult.OK)
            {
                filepath = folderlocation.SelectedPath;
            }
            textBox9.Text = Convert.ToString($"{filepath}\\parkingdata.csv");
            button4.Enabled = true;
            
            
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string csvpath = Convert.ToString(textBox9.Text);
            File.AppendAllText(csvpath, csvcontent.ToString());
            Thread.Sleep(2000);
            System.Environment.Exit(1);
            
        }

        private void textBox10_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
